import { IMenuSidenav } from "../interfaces/menu.sidenav";

export const menuConst: IMenuSidenav[] = [

  { nomeMenu: 'Página pessoal', icon: 'home', description: 'Página pessoal' },
  { nomeMenu: 'Perspectiva', icon: 'explore', description: 'Perspectiva' },
  { nomeMenu: 'Gantt', icon: 'bar_chart', description: 'Objetivo Estrategico' },
  { nomeMenu: 'Visão  hierárquica', icon: 'category', description: 'Iniciativa' }
];
