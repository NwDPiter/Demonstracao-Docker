export interface IMenuSidenav {
  nomeMenu: string;
  description: string;
  icon: string;
}
