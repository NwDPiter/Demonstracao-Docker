import { Routes } from "@angular/router";
import { Inicio } from "../features/inicio/incio";
export const inicioRoute: Routes = [
  { path: 'inicio', component: Inicio }
]
