/***************************************************************************************************
 * APPLICATION IMPORTS
 */

// Substitua:
// import 'zone.js/dist/zone';

// Por:
import 'zone.js';  // Forma correta para versões recentes